#![cfg_attr(not(debug_assertions), windows_subsystem = "windows")]

fn main() {
    phoenix_terminal_lib::run();
}
