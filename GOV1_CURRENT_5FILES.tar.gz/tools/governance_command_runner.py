from __future__ import annotations

import argparse
from dataclasses import dataclass
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import subprocess
import threading
from typing import BinaryIO, Sequence


GOVERNANCE_ARTIFACTS = (
    "AGENTS.md",
    "tools/codex_execution_preflight_gate.py",
    "tools/governance_command_runner.py",
    "config/governance/codex_candidate.schema.json",
    "config/governance/evidence_graph.schema.json",
    "config/governance/failure_class.schema.json",
    "config/governance/gate_report.schema.json",
    "config/governance/root_cause_synonyms.json",
    "knowledge/failure_class_ledger.json",
    "tests/test_codex_execution_preflight_gate.py",
)


def canonical_json_bytes(payload: object) -> bytes:
    return json.dumps(payload, ensure_ascii=False, sort_keys=True, separators=(",", ":")).encode(
        "utf-8"
    )


def sha256_file(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def load_json_object(path: Path) -> dict[str, object]:
    payload = json.loads(path.read_text(encoding="utf-8"))
    if not isinstance(payload, dict):
        raise ValueError("JSON root must be an object")
    return payload


@dataclass(frozen=True)
class CommandResult:
    returncode: int
    stdout_path: str
    stderr_path: str
    stdout_bytes: int
    stderr_bytes: int
    output_limit_exceeded: bool
    spawned: bool = True


def run_command(
    command: Sequence[str],
    cwd: Path,
    stdout_path: Path,
    stderr_path: Path,
    max_stdout_bytes: int,
    max_stderr_bytes: int,
) -> CommandResult:
    if not isinstance(command, (list, tuple)) or not command:
        raise ValueError("command must be a non-empty JSON array")
    if max_stdout_bytes <= 0 or max_stderr_bytes <= 0:
        raise ValueError("output limits must be positive")
    resolved_cwd = cwd.resolve()
    stdout_path = stdout_path.resolve()
    stderr_path = stderr_path.resolve()
    stdout_path.parent.mkdir(parents=True, exist_ok=True)
    stderr_path.parent.mkdir(parents=True, exist_ok=True)
    process = subprocess.Popen(
        [str(part) for part in command],
        cwd=resolved_cwd,
        shell=False,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
    )
    exceeded = threading.Event()
    counts = {"stdout": 0, "stderr": 0}

    def stream(source: BinaryIO, destination: BinaryIO, name: str, limit: int) -> None:
        while True:
            chunk = source.read(8192)
            if not chunk:
                break
            remaining = limit - counts[name]
            if remaining > 0:
                destination.write(chunk[:remaining])
                destination.flush()
                counts[name] += min(len(chunk), remaining)
            if len(chunk) > remaining:
                exceeded.set()
                process.terminate()
                break

    with stdout_path.open("wb") as stdout_file, stderr_path.open("wb") as stderr_file:
        stdout_thread = threading.Thread(
            target=stream,
            args=(process.stdout, stdout_file, "stdout", max_stdout_bytes),
            daemon=True,
        )
        stderr_thread = threading.Thread(
            target=stream,
            args=(process.stderr, stderr_file, "stderr", max_stderr_bytes),
            daemon=True,
        )
        stdout_thread.start()
        stderr_thread.start()
        try:
            returncode = process.wait()
        finally:
            if exceeded.is_set() and process.poll() is None:
                process.terminate()
                try:
                    process.wait(timeout=2)
                except subprocess.TimeoutExpired:
                    process.kill()
                    process.wait()
            stdout_thread.join(timeout=2)
            stderr_thread.join(timeout=2)
    if exceeded.is_set():
        returncode = returncode if returncode != 0 else 1
    return CommandResult(
        returncode=returncode,
        stdout_path=str(stdout_path),
        stderr_path=str(stderr_path),
        stdout_bytes=counts["stdout"],
        stderr_bytes=counts["stderr"],
        output_limit_exceeded=exceeded.is_set(),
    )


def _blocked_result(stdout_path: Path, stderr_path: Path, message: str) -> CommandResult:
    stdout_path = stdout_path.resolve()
    stderr_path = stderr_path.resolve()
    stdout_path.parent.mkdir(parents=True, exist_ok=True)
    stderr_path.parent.mkdir(parents=True, exist_ok=True)
    stdout_path.write_bytes(b"")
    payload = message.encode("utf-8")
    stderr_path.write_bytes(payload)
    return CommandResult(
        returncode=1,
        stdout_path=str(stdout_path),
        stderr_path=str(stderr_path),
        stdout_bytes=0,
        stderr_bytes=len(payload),
        output_limit_exceeded=False,
        spawned=False,
    )


def _candidate_hash(candidate: dict[str, object]) -> str:
    payload = dict(candidate)
    declared = str(payload.pop("candidate_sha256", ""))
    actual = hashlib.sha256(canonical_json_bytes(payload)).hexdigest()
    if declared != actual:
        raise ValueError("candidate hash mismatch")
    return actual


def _fresh_artifact_hashes(root: Path, candidate: dict[str, object]) -> dict[str, str]:
    artifact_lock = candidate.get("artifact_lock", [])
    if not isinstance(artifact_lock, list):
        raise ValueError("artifact_lock must be a list")
    paths = [str(item.get("path", "")) for item in artifact_lock if isinstance(item, dict)]
    if len(paths) != len(set(paths)):
        raise ValueError("artifact paths must be unique")
    for required in GOVERNANCE_ARTIFACTS:
        if required not in paths:
            raise ValueError("governance artifact missing")
    actual = {path: sha256_file(root / path) for path in paths}
    for item in artifact_lock:
        if isinstance(item, dict) and item.get("existing", True):
            path = str(item.get("path", ""))
            if item.get("sha256") != actual[path]:
                raise ValueError("artifact hash mismatch")
    if candidate.get("agents_sha256") != actual["AGENTS.md"]:
        raise ValueError("AGENTS hash mismatch")
    return actual


def _fresh_gate(root: Path, candidate: dict[str, object]) -> tuple[str, dict[str, str]]:
    created = datetime.fromisoformat(str(candidate["created_at_utc"]))
    expires = datetime.fromisoformat(str(candidate["expires_at_utc"]))
    if created.tzinfo is None or expires.tzinfo is None:
        raise ValueError("candidate timestamps must be timezone-aware")
    if created.utcoffset() != timezone.utc.utcoffset(created):
        raise ValueError("created_at_utc must be UTC")
    if expires.utcoffset() != timezone.utc.utcoffset(expires):
        raise ValueError("expires_at_utc must be UTC")
    now = datetime.now(timezone.utc)
    if not (created <= now < expires):
        raise ValueError("candidate expired")
    if str(root.resolve()) != candidate.get("workspace"):
        raise ValueError("workspace mismatch")
    candidate_hash = _candidate_hash(candidate)
    artifact_hashes = _fresh_artifact_hashes(root, candidate)
    return candidate_hash, artifact_hashes


def run_governed_command(
    command_id: str,
    candidate_path: Path,
    report_path: Path,
    cwd: Path,
    stdout_path: Path,
    stderr_path: Path,
    max_stdout_bytes: int,
    max_stderr_bytes: int,
    agents_path: Path = Path("AGENTS.md"),
    ledger_path: Path = Path("knowledge/failure_class_ledger.json"),
    synonyms_path: Path = Path("config/governance/root_cause_synonyms.json"),
) -> CommandResult:
    resolved_cwd = cwd.resolve()
    try:
        candidate = load_json_object((resolved_cwd / candidate_path).resolve())
        report = load_json_object((resolved_cwd / report_path).resolve())
        commands = candidate.get("execution_manifest", {}).get("commands", [])
        matches = [
            command
            for command in commands
            if isinstance(command, dict) and command.get("command_id") == command_id
        ]
        if len(matches) != 1:
            return _blocked_result(stdout_path, stderr_path, "UNKNOWN_GOVERNED_COMMAND")
        command = matches[0]
        if command.get("preflight") or not command.get("via_runner"):
            return _blocked_result(stdout_path, stderr_path, "GOVERNED_COMMAND_NOT_RUNNER_ALLOWED")
        fresh_candidate_hash, fresh_artifact_hashes = _fresh_gate(resolved_cwd, candidate)
        if report.get("status") != "PASS":
            return _blocked_result(stdout_path, stderr_path, "GOVERNANCE_GATE_NOT_PASS")
        if report.get("candidate_sha256") != fresh_candidate_hash:
            return _blocked_result(stdout_path, stderr_path, "CANDIDATE_REPORT_MISMATCH")
        report_hashes = report.get("artifact_hashes")
        if not isinstance(report_hashes, dict):
            return _blocked_result(stdout_path, stderr_path, "GOVERNANCE_REPORT_INVALID")
        for path, digest in fresh_artifact_hashes.items():
            if report_hashes.get(path) != digest:
                return _blocked_result(stdout_path, stderr_path, "GOVERNANCE_ARTIFACT_STALE")
        if report.get("validator_version") != candidate.get("validator_version"):
            return _blocked_result(stdout_path, stderr_path, "GOVERNANCE_VERSION_MISMATCH")
        if sha256_file((resolved_cwd / ledger_path).resolve()) != fresh_artifact_hashes[
            "knowledge/failure_class_ledger.json"
        ]:
            return _blocked_result(stdout_path, stderr_path, "LEDGER_STALE")
        if sha256_file((resolved_cwd / synonyms_path).resolve()) != fresh_artifact_hashes[
            "config/governance/root_cause_synonyms.json"
        ]:
            return _blocked_result(stdout_path, stderr_path, "GOVERNANCE_ARTIFACT_STALE")
        argv = command.get("argv")
        if not isinstance(argv, list) or not all(isinstance(part, str) for part in argv):
            return _blocked_result(stdout_path, stderr_path, "GOVERNED_COMMAND_ARGV_INVALID")
        budget = candidate.get("output_budget", {})
        if not isinstance(budget, dict):
            return _blocked_result(stdout_path, stderr_path, "OUTPUT_BUDGET_INVALID")
        max_stdout_bytes = int(budget.get("max_stdout_bytes", 0))
        max_stderr_bytes = int(budget.get("max_stderr_bytes", 0))
        if max_stdout_bytes <= 0 or max_stderr_bytes <= 0:
            return _blocked_result(stdout_path, stderr_path, "OUTPUT_BUDGET_INVALID")
    except Exception as error:
        return _blocked_result(stdout_path, stderr_path, f"GOVERNED_COMMAND_PREFLIGHT_FAILED:{error}")
    return run_command(
        argv,
        resolved_cwd,
        stdout_path,
        stderr_path,
        max_stdout_bytes,
        max_stderr_bytes,
    )


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--command")
    parser.add_argument("--cwd", required=True)
    parser.add_argument("--stdout", required=True)
    parser.add_argument("--stderr", required=True)
    parser.add_argument("--max-stdout-bytes", required=True, type=int)
    parser.add_argument("--max-stderr-bytes", required=True, type=int)
    parser.add_argument("--command-id")
    parser.add_argument("--candidate")
    parser.add_argument("--report")
    args = parser.parse_args(argv)
    if args.command_id:
        if not args.candidate or not args.report:
            raise ValueError("governed command requires candidate and report")
        result = run_governed_command(
            args.command_id,
            Path(args.candidate),
            Path(args.report),
            Path(args.cwd),
            Path(args.stdout),
            Path(args.stderr),
            args.max_stdout_bytes,
            args.max_stderr_bytes,
        )
    else:
        command = json.loads(args.command)
        if not isinstance(command, list) or not all(isinstance(item, str) for item in command):
            raise ValueError("command must be a JSON string array")
        result = run_command(
            command,
            Path(args.cwd),
            Path(args.stdout),
            Path(args.stderr),
            args.max_stdout_bytes,
            args.max_stderr_bytes,
        )
    print(f"COMMAND_RESULT:{'FAIL' if result.returncode else 'PASS'}")
    print(f"RETURN_CODE:{result.returncode}")
    print(f"OUTPUT_LIMIT_EXCEEDED:{str(result.output_limit_exceeded).upper()}")
    print(f"SPAWNED:{str(result.spawned).upper()}")
    print(f"STDOUT_BYTES:{result.stdout_bytes}")
    print(f"STDERR_BYTES:{result.stderr_bytes}")
    return result.returncode


if __name__ == "__main__":
    raise SystemExit(main())
